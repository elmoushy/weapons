# Files_Endpoints module for Google Drive-like functionality

default_app_config = 'Files_Endpoints.apps.FilesEndpointsConfig'
